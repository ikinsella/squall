#!bin/bash
export PATH=$(pwd)/R/bin:$PATH
