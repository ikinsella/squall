#!/bin/sh
cat <<EOF
$*
EOF
